Here is the 'Hello World' function in Python, ready for deployment:

def hello_world():
    print("Hello, World!")
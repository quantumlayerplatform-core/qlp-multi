Here is the 'Hello World' function in Python:

def hello_world():
    print("Hello, World!")

This function simply prints the string "Hello, World!" to the console.

The choice of Python for this task is appropriate for a few reasons:

1. Python is a widely-used, general-purpose programming language that is known for its simplicity and readability. The 'Hello World' program is a classic introductory example, and Python's syntax makes it easy to implement.

2. Python has a large and active community, with a wealth of libraries and tools available. This makes it a popular choice for a wide range of applications, from web development to data analysis and machine learning.

3. Python's interpreted nature and dynamic typing make it a good choice for quick prototyping and experimentation, which is often the case with 'Hello World' programs.

4. Python is cross-platform, meaning the same code can run on Windows, macOS, and Linux without modification. This makes it a versatile choice for a simple program like this.

The 'hello_world()' function itself is straightforward. It uses the built-in 'print()' function to output the string "Hello, World!" to the console. This is a common way to demonstrate the basic functionality of a programming language and is often used as the first step in learning a new language.

Overall, the choice of Python for this 'Hello World' task is well-suited, as it leverages the language's simplicity, readability, and widespread adoption to provide a clear and concise example of a fundamental programming concept.
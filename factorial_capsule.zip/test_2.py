import math

def factorial(n):
    if n < 0:
        raise ValueError("Factorial is not defined for negative numbers")
    if n == 0:
        return 1
    return math.factorial(n)

# Test cases
print(factorial(0))  # Expected output: 1
print(factorial(5))  # Expected output: 120
try:
    factorial(-1)
except ValueError as e:
    print(str(e))  # Expected output: Factorial is not defined for negative numbers